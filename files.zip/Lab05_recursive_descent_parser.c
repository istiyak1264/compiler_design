/*
 * SESSION 5 — Use of CFGs for Parsing (Recursive Descent Parser)
 * OBJECTIVE: Implement a recursive descent parser for arithmetic expressions.
 *
 * Grammar (left-recursion removed):
 *   <Exp>    → <Term> <Exp'>
 *   <Exp'>   → + <Term> <Exp'>  |  - <Term> <Exp'>  |  ε
 *   <Term>   → <Factor> <Term'>
 *   <Term'>  → * <Factor> <Term'>  |  / <Factor> <Term'>  |  ε
 *   <Factor> → ( <Exp> )  |  ID  |  NUM
 *
 * ID  → a | b | c | d | e
 * NUM → 0-9
 *
 * Also implements the simple CFG from the PDF:
 *   S → b | AB
 *   A → a | aA
 *   B → b
 * with language {b, ab, aab, aaab, ...}
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ============================================================
   PART 1: Simple CFG  S → b | AB,  A → a|aA,  B → b
   Language: { b, ab, aab, aaab, ... }
   ============================================================ */

char str1[100];
int  i1, f1, l1;

void A1();
void B1();

void S1() {
    if (str1[i1] == 'b') {
        i1++; f1 = 1; return;
    } else {
        A1();
        if (f1) { B1(); return; }
    }
}

void A1() {
    if (str1[i1] == 'a') {
        i1++; f1 = 1;
    } else {
        f1 = 0; return;
    }
    if (i1 < l1 - 1) A1();
}

void B1() {
    if (str1[i1] == 'b') {
        i1++; f1 = 1; return;
    } else {
        f1 = 0; return;
    }
}

void testSimpleCFG(const char *input) {
    strncpy(str1, input, 99);
    i1 = 0; f1 = 0;
    l1 = strlen(str1);
    S1();
    printf("  Input \"%s\" → %s\n", input,
           (f1 && i1 == l1) ? "ACCEPTED" : "REJECTED");
}

/* ============================================================
   PART 2: Recursive Descent Parser for Arithmetic Expressions
   Grammar:
     Exp    → Term Exp'
     Exp'   → +Term Exp' | -Term Exp' | ε
     Term   → Factor Term'
     Term'  → *Factor Term' | /Factor Term' | ε
     Factor → (Exp) | ID | NUM
   ============================================================ */

char expr[200];
int  pos;      /* current position in expr[] */
int  parseOK;  /* 0 = error encountered */
char parseLog[2000];
int  logLen;

void logMsg(const char *msg) {
    logLen += snprintf(parseLog + logLen, sizeof(parseLog) - logLen, "%s\n", msg);
}

char cur() { return expr[pos]; }
void advance() { if (expr[pos]) pos++; }
void skipSpaces() { while (expr[pos] == ' ' || expr[pos] == '\t') pos++; }

void Exp();
void ExpPrime();
void Term();
void TermPrime();
void Factor();

void Exp() {
    logMsg("  Exp → Term Exp'");
    Term();
    ExpPrime();
}

void ExpPrime() {
    skipSpaces();
    if (cur() == '+') {
        logMsg("  Exp' → + Term Exp'");
        advance(); skipSpaces();
        Term(); ExpPrime();
    } else if (cur() == '-') {
        logMsg("  Exp' → - Term Exp'");
        advance(); skipSpaces();
        Term(); ExpPrime();
    } else {
        logMsg("  Exp' → ε");
    }
}

void Term() {
    logMsg("  Term → Factor Term'");
    Factor();
    TermPrime();
}

void TermPrime() {
    skipSpaces();
    if (cur() == '*') {
        logMsg("  Term' → * Factor Term'");
        advance(); skipSpaces();
        Factor(); TermPrime();
    } else if (cur() == '/') {
        logMsg("  Term' → / Factor Term'");
        advance(); skipSpaces();
        Factor(); TermPrime();
    } else {
        logMsg("  Term' → ε");
    }
}

void Factor() {
    skipSpaces();
    char c = cur();
    char buf[64];

    if (c == '(') {
        logMsg("  Factor → ( Exp )");
        advance();
        Exp();
        skipSpaces();
        if (cur() == ')') advance();
        else {
            logMsg("  [ERROR] Expected ')'");
            parseOK = 0;
        }
    } else if (c >= 'a' && c <= 'e') {
        snprintf(buf, sizeof(buf), "  Factor → ID ('%c')", c);
        logMsg(buf);
        advance();
    } else if (c >= '0' && c <= '9') {
        snprintf(buf, sizeof(buf), "  Factor → NUM ('%c')", c);
        logMsg(buf);
        advance();
    } else {
        snprintf(buf, sizeof(buf), "  [ERROR] Unexpected character '%c' at position %d", c, pos);
        logMsg(buf);
        parseOK = 0;
    }
}

void parseExpression(const char *input) {
    strncpy(expr, input, 199);
    pos = 0; parseOK = 1; logLen = 0;
    parseLog[0] = '\0';

    printf("\n  Parsing: \"%s\"\n", input);
    Exp();
    skipSpaces();
    if (cur() != '\0') {
        char buf[64];
        snprintf(buf, sizeof(buf), "  [ERROR] Unexpected token '%c' after expression", cur());
        logMsg(buf);
        parseOK = 0;
    }
    printf("%s", parseLog);
    printf("  Result: %s\n", parseOK ? "ACCEPTED" : "REJECTED (parse error)");
}

/* ============================================================
   PART 3: Assignment #5 grammar (simplified)
   <stat>      → <asgn_stat> | <dscn_stat> | <loop_stat>
   <asgn_stat> → id = <smpl_expn>
   <dscn_stat> → if ( <expn> ) <stat> [else <stat>]
   <loop_stat> → while ( <expn> ) <stat>
   ============================================================ */

char stmt[300];
int  spos;
int  stmtOK;

char scur() { return stmt[spos]; }
void sadvance() { if (stmt[spos]) spos++; }
void sskip() { while (stmt[spos]==' '||stmt[spos]=='\t') spos++; }

void smatch(const char *tok) {
    sskip();
    int tlen = strlen(tok);
    if (strncmp(stmt + spos, tok, tlen) == 0) {
        spos += tlen;
        printf("  matched '%s'\n", tok);
    } else {
        printf("  [ERROR] expected '%s' got '%.10s'\n", tok, stmt+spos);
        stmtOK = 0;
    }
}

void sExp() {
    /* simplified: consume until ) or ; */
    sskip();
    int depth = 0;
    while (stmt[spos] && !((stmt[spos]==')' && depth==0) || stmt[spos]==';')) {
        if (stmt[spos]=='(') depth++;
        if (stmt[spos]==')') depth--;
        spos++;
    }
    printf("  matched <expn>\n");
}

void sStat();

void sAsgnStat() {
    sskip();
    /* consume id */
    char id[32]; int j=0;
    while (stmt[spos] && (stmt[spos]!=' ' && stmt[spos]!='='))
        id[j++] = stmt[spos++];
    id[j]='\0';
    printf("  matched id '%s'\n", id);
    smatch("=");
    sExp();
    smatch(";");
}

void sDcsnStat() {
    smatch("if"); smatch("("); sExp(); smatch(")");
    sStat();
    sskip();
    if (strncmp(stmt+spos,"else",4)==0) {
        smatch("else");
        sStat();
    }
}

void sLoopStat() {
    sskip();
    if (strncmp(stmt+spos,"while",5)==0) {
        smatch("while"); smatch("("); sExp(); smatch(")"); sStat();
    } else if (strncmp(stmt+spos,"for",3)==0) {
        smatch("for"); smatch("("); sAsgnStat(); sExp(); smatch(";"); sAsgnStat(); smatch(")"); sStat();
    }
}

void sStat() {
    sskip();
    if (strncmp(stmt+spos,"if",2)==0)    { printf("  Stat → dcsn_stat\n"); sDcsnStat(); }
    else if (strncmp(stmt+spos,"while",5)==0||strncmp(stmt+spos,"for",3)==0)
                                          { printf("  Stat → loop_stat\n"); sLoopStat(); }
    else                                  { printf("  Stat → asgn_stat\n"); sAsgnStat(); }
}

void parseStatement(const char *input) {
    strncpy(stmt, input, 299);
    spos=0; stmtOK=1;
    printf("\n  Parsing statement: \"%s\"\n", input);
    sStat();
    printf("  Result: %s\n", stmtOK ? "ACCEPTED" : "REJECTED");
}

/* ============================================================
   MAIN
   ============================================================ */
int main() {
    printf("===========================================\n");
    printf("   RECURSIVE DESCENT PARSER — SESSION 05  \n");
    printf("===========================================\n");

    /* --- Part 1: Simple CFG tests --- */
    printf("\n[PART 1] Simple CFG: S→b|AB, A→a|aA, B→b\n");
    printf("Language: {b, ab, aab, aaab, ...}\n");
    testSimpleCFG("b");
    testSimpleCFG("ab");
    testSimpleCFG("aab");
    testSimpleCFG("aaab");
    testSimpleCFG("a");
    testSimpleCFG("ba");
    testSimpleCFG("bb");

    /* --- Part 2: Arithmetic expression parser --- */
    printf("\n[PART 2] Arithmetic Expression Parser\n");
    printf("Grammar: Exp→Term Exp', Term→Factor Term', Factor→(Exp)|ID|NUM\n");
    parseExpression("a+b*c");
    parseExpression("(a+b)*c");
    parseExpression("a-b*c/d+e");
    parseExpression("a+(b*c");  /* error: missing ) */
    parseExpression("a@b");     /* error: invalid token */

    /* --- Part 3: Statement parser --- */
    printf("\n[PART 3] Statement Parser (Assignment #5)\n");
    parseStatement("x = a+b;");
    parseStatement("if(x) y = 1;");
    parseStatement("while(i) x = x+1;");

    printf("\n===========================================\n");
    return 0;
}
