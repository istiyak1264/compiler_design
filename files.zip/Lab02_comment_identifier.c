/* EXPERIMENT 2
 * OBJECTIVE: Write a C program to identify whether a given line is a comment.
 * Detects single-line and multi-line comments.
 * Also reports: type of comment, length of comment text.
 */

#include <stdio.h>
#include <string.h>

#define MAX 200

int main() {
    char com[MAX];
    int choice = 1;

    printf("===========================================\n");
    printf("      COMMENT IDENTIFIER - LAB 02         \n");
    printf("===========================================\n");

    while (choice) {
        int i = 2, a = 0;

        printf("\nEnter a line to check (max %d chars): ", MAX - 1);
        fgets(com, MAX, stdin);

        /* Remove trailing newline */
        int slen = strlen(com);
        if (slen > 0 && com[slen - 1] == '\n') {
            com[slen - 1] = '\0';
            slen--;
        }

        /* ---- Check for comment ---- */
        if (com[0] == '/') {

            /* Single-line comment: // */
            if (com[1] == '/') {
                printf("\n  Result  : It IS a comment\n");
                printf("  Type    : Single-line comment (//)\n");

                /* Count characters in comment text (after //) */
                int txtLen = slen - 2;
                printf("  Length  : %d character(s) in comment text\n", txtLen > 0 ? txtLen : 0);
                if (txtLen > 0)
                    printf("  Content : \"%s\"\n", com + 2);

            }
            /* Multi-line comment style */
            else if (com[1] == '*') {
                for (i = 2; i <= slen - 1; i++) {
                    if (com[i] == '*' && com[i + 1] == '/') {
                        printf("\n  Result  : It IS a comment\n");
                        printf("  Type    : Multi-line comment (/* ... */)\n");

                        /* Extract content between opening and closing markers */
                        int contentLen = i - 2;
                        printf("  Length  : %d character(s) in comment text\n", contentLen > 0 ? contentLen : 0);
                        if (contentLen > 0) {
                            char content[MAX];
                            strncpy(content, com + 2, contentLen);
                            content[contentLen] = '\0';
                            printf("  Content : \"%s\"\n", content);
                        }
                        a = 1;
                        break;
                    }
                }
                if (a == 0) {
                    printf("\n  Result  : It is NOT a valid comment\n");
                    printf("  Reason  : Multi-line comment not properly closed (missing */)\n");
                }
            }
            /* / followed by something else — not a comment */
            else {
                printf("\n  Result  : It is NOT a comment\n");
                printf("  Reason  : Starts with '/' but not followed by '/' or '*'\n");
            }
        }
        /* Doesn't start with / */
        else {
            printf("\n  Result  : It is NOT a comment\n");
            printf("  Reason  : Does not begin with '/'\n");
        }

        printf("\nCheck another line? (1=Yes / 0=No): ");
        scanf("%d", &choice);
        getchar(); /* consume leftover newline */
    }

    printf("\n===========================================\n");
    printf("  Thank you for using Comment Identifier!  \n");
    printf("===========================================\n");
    return 0;
}
