/*
 * SESSION 4 — Detecting Simple Syntax Errors
 * OBJECTIVE: Detect and report simple syntax errors in a C source program.
 *
 * Errors detected:
 *  1. Duplicate tokens (e.g., ;; or int int)
 *  2. Unbalanced curly braces  { }
 *  3. Unbalanced parentheses  ( )
 *  4. Unmatched 'else' (no matching 'if')
 *  5. Duplicate identifier declarations (uses symbol table)
 *
 * Input: Plain C source code entered interactively or via stdin.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINES  200
#define MAX_LINE   512
#define MAX_SYMS   100
#define MAX_LEN    64

/* ---- Simple symbol table for duplicate-declaration detection ---- */
typedef struct { char name[MAX_LEN]; char scope[MAX_LEN]; } Sym;
Sym symTable[MAX_SYMS];
int symCount = 0;

int symExists(const char *name, const char *scope) {
    for (int i = 0; i < symCount; i++)
        if (strcmp(symTable[i].name, name) == 0 &&
            strcmp(symTable[i].scope, scope) == 0)
            return 1;
    return 0;
}

void symInsert(const char *name, const char *scope) {
    if (symCount < MAX_SYMS) {
        strcpy(symTable[symCount].name,  name);
        strcpy(symTable[symCount].scope, scope);
        symCount++;
    }
}

/* ---- List of C keywords ---- */
const char *keywords[] = {
    "int","float","double","char","void","long","short","unsigned","signed",
    "if","else","while","for","do","return","break","continue",
    "switch","case","default","struct","typedef","enum","static",
    "const","extern","register","auto","sizeof","goto",NULL
};

int isKeyword(const char *s) {
    for (int i = 0; keywords[i]; i++)
        if (strcmp(keywords[i], s) == 0) return 1;
    return 0;
}

int isTypeKw(const char *s) {
    const char *types[] = {"int","float","double","char","void","long","short",NULL};
    for (int i = 0; types[i]; i++)
        if (strcmp(types[i], s) == 0) return 1;
    return 0;
}

/* ---- Error list ---- */
typedef struct { int line; char msg[256]; } Error;
Error errors[500];
int errCount = 0;

void addError(int line, const char *msg) {
    if (errCount < 500) {
        errors[errCount].line = line;
        strcpy(errors[errCount].msg, msg);
        errCount++;
    }
}

/* ======================================================
   MAIN ANALYSIS FUNCTION
   ====================================================== */
void analyzeSource(char lines[][MAX_LINE], int lineCount) {

    /* ---- 1. Brace / paren balance ---- */
    int braceDepth  = 0;   /* { */
    int parenDepth  = 0;   /* ( */
    int ifCount     = 0;
    int elseCount   = 0;

    /* For duplicate-token detection: remember last token per line */
    /* For identifier declarations: track current data type keyword */

    /* Scope stack (simple: use brace depth as scope id) */
    char scopeStack[50][MAX_LEN];
    int  scopeTop = 0;
    strcpy(scopeStack[0], "global");

    /* ---- Walk every line ---- */
    for (int ln = 0; ln < lineCount; ln++) {
        char *line = lines[ln];
        int lineNo = ln + 1;

        /* ---- Tokenise the line ---- */
        /* We produce a list of tokens (strings) from raw source */
        char tokens[128][MAX_LEN];
        int  tCount = 0;
        int  i = 0;
        int  lineLen = strlen(line);

        /* Strip // comments */
        char cleanLine[MAX_LINE];
        strncpy(cleanLine, line, MAX_LINE - 1);
        for (int ci = 0; ci < (int)strlen(cleanLine) - 1; ci++) {
            if (cleanLine[ci] == '/' && cleanLine[ci+1] == '/') {
                cleanLine[ci] = '\0';
                break;
            }
        }
        lineLen = strlen(cleanLine);

        i = 0;
        while (i < lineLen) {
            /* skip whitespace */
            if (isspace(cleanLine[i])) { i++; continue; }

            /* identifier or keyword */
            if (isalpha(cleanLine[i]) || cleanLine[i] == '_') {
                char tok[MAX_LEN]; int ti = 0;
                while (i < lineLen && (isalnum(cleanLine[i]) || cleanLine[i] == '_'))
                    tok[ti++] = cleanLine[i++];
                tok[ti] = '\0';
                if (tCount < 127) strcpy(tokens[tCount++], tok);
                continue;
            }

            /* number */
            if (isdigit(cleanLine[i])) {
                char tok[MAX_LEN]; int ti = 0;
                while (i < lineLen && (isdigit(cleanLine[i]) || cleanLine[i] == '.'))
                    tok[ti++] = cleanLine[i++];
                tok[ti] = '\0';
                if (tCount < 127) strcpy(tokens[tCount++], tok);
                continue;
            }

            /* single-char token */
            char tok[3] = {cleanLine[i], '\0', '\0'};
            /* two-char operators */
            if (i + 1 < lineLen) {
                char c2 = cleanLine[i+1];
                if ((cleanLine[i]=='=' && c2=='=') ||
                    (cleanLine[i]=='!' && c2=='=') ||
                    (cleanLine[i]=='<' && c2=='=') ||
                    (cleanLine[i]=='>' && c2=='=') ||
                    (cleanLine[i]=='+' && c2=='+') ||
                    (cleanLine[i]=='-' && c2=='-')) {
                    tok[1] = c2;
                    i++;
                }
            }
            if (tCount < 127) strcpy(tokens[tCount++], tok);
            i++;
        }

        /* ---- Now analyse tokens on this line ---- */

        /* Detect duplicate consecutive tokens (except inside for(;;)) */
        int inForHeader = 0;
        for (int t = 0; t < tCount; t++) {
            /* track 'for' */
            if (strcmp(tokens[t], "for") == 0) inForHeader = 1;
            if (inForHeader && strcmp(tokens[t], ")") == 0) inForHeader = 0;

            /* check duplicate */
            if (t > 0 &&
                strcmp(tokens[t], tokens[t-1]) == 0 &&
                !inForHeader) {
                /* Allow consecutive same-name identifiers only if they're different */
                /* Duplicate ; is always bad; duplicate keywords are bad */
                char msg[256];
                snprintf(msg, sizeof(msg),
                         "Duplicate token '%s'", tokens[t]);
                addError(lineNo, msg);
            }

            /* Count braces */
            if (strcmp(tokens[t], "{") == 0) {
                braceDepth++;
                if (scopeTop < 49) {
                    scopeTop++;
                    snprintf(scopeStack[scopeTop], MAX_LEN, "block_%d_%d", lineNo, braceDepth);
                }
            }
            if (strcmp(tokens[t], "}") == 0) {
                braceDepth--;
                if (braceDepth < 0) {
                    addError(lineNo, "Misplaced '}'  — no matching '{'");
                    braceDepth = 0;
                }
                if (scopeTop > 0) scopeTop--;
            }

            /* Count parens */
            if (strcmp(tokens[t], "(") == 0) parenDepth++;
            if (strcmp(tokens[t], ")") == 0) {
                parenDepth--;
                if (parenDepth < 0) {
                    addError(lineNo, "Misplaced ')' — no matching '('");
                    parenDepth = 0;
                }
            }

            /* Count if / else */
            if (strcmp(tokens[t], "if") == 0)   ifCount++;
            if (strcmp(tokens[t], "else") == 0) {
                elseCount++;
                if (elseCount > ifCount) {
                    addError(lineNo, "Unmatched 'else' — no preceding 'if'");
                    elseCount = ifCount; /* reset to avoid cascade */
                }
            }

            /* Duplicate identifier declaration check:
               pattern: <type_kw> <id> where <id> already in current scope */
            if (isTypeKw(tokens[t]) && t + 1 < tCount && !isKeyword(tokens[t+1])) {
                const char *varName = tokens[t+1];
                const char *scope   = scopeStack[scopeTop];
                if (symExists(varName, scope)) {
                    char msg[256];
                    snprintf(msg, sizeof(msg),
                             "Duplicate declaration of identifier '%s' in scope '%s'",
                             varName, scope);
                    addError(lineNo, msg);
                } else {
                    symInsert(varName, scope);
                }
            }
        }
    } /* end line loop */

    /* ---- Post-loop checks ---- */
    if (braceDepth > 0)
        addError(-1, "Unbalanced braces: missing closing '}'");
    if (parenDepth > 0)
        addError(-1, "Unbalanced parentheses: missing closing ')'");
}

/* ======================================================
   MAIN
   ====================================================== */
int main() {
    char lines[MAX_LINES][MAX_LINE];
    int  lineCount = 0;

    printf("===========================================\n");
    printf("   SYNTAX ERROR DETECTOR — SESSION 04     \n");
    printf("===========================================\n");
    printf("Enter source code (blank line to finish):\n\n");

    while (lineCount < MAX_LINES) {
        if (!fgets(lines[lineCount], MAX_LINE, stdin)) break;
        /* stop on blank line */
        if (lines[lineCount][0] == '\n' || lines[lineCount][0] == '\0') break;
        /* strip newline */
        lines[lineCount][strcspn(lines[lineCount], "\n")] = '\0';
        lineCount++;
    }

    printf("\n--- Source with line numbers ---\n");
    for (int i = 0; i < lineCount; i++)
        printf("  %3d | %s\n", i+1, lines[i]);

    analyzeSource(lines, lineCount);

    printf("\n--- Syntax Error Report ---\n");
    if (errCount == 0) {
        printf("  No errors detected.\n");
    } else {
        for (int e = 0; e < errCount; e++) {
            if (errors[e].line == -1)
                printf("  [EOF]  : %s\n", errors[e].msg);
            else
                printf("  [Line %3d]: %s\n", errors[e].line, errors[e].msg);
        }
        printf("\n  Total errors found: %d\n", errCount);
    }

    printf("===========================================\n");
    return 0;
}
