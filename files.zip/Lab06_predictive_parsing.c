/*
 * SESSION 6 — Predictive Parsing (LL(1))
 * OBJECTIVE: Manual implementation of LL(1) parsing.
 *
 * Grammar (from Assignment #6 in PDF):
 *   S  → a X d
 *   X  → Y Z
 *   Y  → b  |  ε
 *   Z  → c X  |  ε
 *
 * Tasks:
 *  1. Compute FIRST and FOLLOW sets
 *  2. Build the LL(1) predictive parsing table
 *  3. Simulate LL(1) parser on input "abcd"
 *
 * Also demonstrates the standard arithmetic grammar from the PDF:
 *   E  → T E'
 *   E' → +T E' | ε
 *   T  → F T'
 *   T' → *F T' | ε
 *   F  → (E) | id
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

/* ============================================================
   DATA STRUCTURES
   ============================================================ */
#define MAX_NT   20   /* max non-terminals */
#define MAX_T    20   /* max terminals (incl. $) */
#define MAX_PROD 40   /* max productions */
#define MAX_SYM  10   /* max symbols in one production RHS */
#define MAX_LEN  20   /* max string length */
#define EPSILON  "eps"
#define ENDMARK  "$"

typedef struct {
    char lhs[MAX_LEN];             /* left-hand side non-terminal */
    char rhs[MAX_SYM][MAX_LEN];   /* right-hand side symbols */
    int  rhsLen;                   /* number of symbols in rhs (0 = epsilon) */
} Production;

typedef struct {
    char  nonTerminals[MAX_NT][MAX_LEN];
    int   ntCount;
    char  terminals[MAX_T][MAX_LEN];
    int   tCount;
    Production prods[MAX_PROD];
    int   prodCount;
    char  startSymbol[MAX_LEN];
    /* FIRST and FOLLOW: stored as sets of strings */
    char  first[MAX_NT][MAX_T][MAX_LEN];
    int   firstCount[MAX_NT];
    char  follow[MAX_NT][MAX_T][MAX_LEN];
    int   followCount[MAX_NT];
    /* LL(1) table: table[nt][t] = production index, -1 = error */
    int   table[MAX_NT][MAX_T];
} Grammar;

Grammar G;

/* ---- Index helpers ---- */
int ntIndex(const char *s) {
    for (int i = 0; i < G.ntCount; i++)
        if (strcmp(G.nonTerminals[i], s) == 0) return i;
    return -1;
}
int tIndex(const char *s) {
    for (int i = 0; i < G.tCount; i++)
        if (strcmp(G.terminals[i], s) == 0) return i;
    return -1;
}
int isNT(const char *s) { return ntIndex(s) != -1; }

/* ---- Set helpers ---- */
int setContains(char set[][MAX_LEN], int count, const char *s) {
    for (int i = 0; i < count; i++)
        if (strcmp(set[i], s) == 0) return 1;
    return 0;
}
int setAdd(char set[][MAX_LEN], int *count, const char *s) {
    if (!setContains(set, *count, s)) {
        strcpy(set[(*count)++], s);
        return 1; /* added */
    }
    return 0;
}

/* ============================================================
   FIRST SET COMPUTATION  (iterative, no recursion loops)
   ============================================================ */
void computeFirstIter() {
    /* Iterative fixed-point computation */
    int changed = 1;
    for (int i = 0; i < G.ntCount; i++) G.firstCount[i] = 0;

    while (changed) {
        changed = 0;
        for (int p = 0; p < G.prodCount; p++) {
            int Ai = ntIndex(G.prods[p].lhs);
            if (G.prods[p].rhsLen == 0) {
                changed |= setAdd(G.first[Ai], &G.firstCount[Ai], EPSILON);
                continue;
            }
            int allEps = 1;
            for (int k = 0; k < G.prods[p].rhsLen; k++) {
                const char *sym = G.prods[p].rhs[k];
                if (!isNT(sym)) {
                    /* terminal */
                    changed |= setAdd(G.first[Ai], &G.firstCount[Ai], sym);
                    allEps = 0; break;
                } else {
                    int si = ntIndex(sym);
                    int symHasEps = 0;
                    for (int x = 0; x < G.firstCount[si]; x++) {
                        if (strcmp(G.first[si][x], EPSILON) == 0) { symHasEps = 1; continue; }
                        changed |= setAdd(G.first[Ai], &G.firstCount[Ai], G.first[si][x]);
                    }
                    if (!symHasEps) { allEps = 0; break; }
                }
            }
            if (allEps) changed |= setAdd(G.first[Ai], &G.firstCount[Ai], EPSILON);
        }
    }
}

/* Helper: compute FIRST of a string of symbols, into result set */
int firstOfString(char rhs[][MAX_LEN], int rhsLen, char result[][MAX_LEN], int *rCount) {
    if (rhsLen == 0) { setAdd(result, rCount, EPSILON); return 1; }
    int allEps = 1;
    for (int k = 0; k < rhsLen; k++) {
        const char *sym = rhs[k];
        if (!isNT(sym)) {
            setAdd(result, rCount, sym);
            allEps = 0; break;
        } else {
            int si = ntIndex(sym);
            int symHasEps = 0;
            for (int x = 0; x < G.firstCount[si]; x++) {
                if (strcmp(G.first[si][x], EPSILON)==0) { symHasEps=1; continue; }
                setAdd(result, rCount, G.first[si][x]);
            }
            if (!symHasEps) { allEps=0; break; }
        }
    }
    if (allEps) setAdd(result, rCount, EPSILON);
    return allEps;
}

void computeFirst() { computeFirstIter(); }

/* ============================================================
   FOLLOW SET COMPUTATION
   ============================================================ */
void computeFollow() {
    for (int i = 0; i < G.ntCount; i++) G.followCount[i] = 0;
    int si = ntIndex(G.startSymbol);
    setAdd(G.follow[si], &G.followCount[si], ENDMARK);

    int changed = 1;
    while (changed) {
        changed = 0;
        for (int p = 0; p < G.prodCount; p++) {
            for (int k = 0; k < G.prods[p].rhsLen; k++) {
                const char *B = G.prods[p].rhs[k];
                if (!isNT(B)) continue;
                int bi = ntIndex(B);
                int Ai = ntIndex(G.prods[p].lhs);

                /* Compute FIRST of beta = rhs[k+1..] */
                char beta[MAX_T][MAX_LEN]; int bCount = 0;
                int betaHasEps = firstOfString(
                    (char (*)[MAX_LEN])(G.prods[p].rhs + k + 1),
                    G.prods[p].rhsLen - k - 1,
                    beta, &bCount);

                for (int x = 0; x < bCount; x++)
                    if (strcmp(beta[x], EPSILON) != 0)
                        changed |= setAdd(G.follow[bi], &G.followCount[bi], beta[x]);

                if (betaHasEps)
                    for (int x = 0; x < G.followCount[Ai]; x++)
                        changed |= setAdd(G.follow[bi], &G.followCount[bi], G.follow[Ai][x]);
            }
        }
    }
}

/* ============================================================
   BUILD LL(1) TABLE
   ============================================================ */
void buildLL1Table() {
    for (int i = 0; i < G.ntCount; i++)
        for (int j = 0; j < G.tCount; j++)
            G.table[i][j] = -1;

    for (int p = 0; p < G.prodCount; p++) {
        int Ai = ntIndex(G.prods[p].lhs);
        char fst[MAX_T][MAX_LEN]; int fc = 0;
        int hasEps = firstOfString(G.prods[p].rhs, G.prods[p].rhsLen, fst, &fc);

        for (int x = 0; x < fc; x++) {
            if (strcmp(fst[x], EPSILON)==0) continue;
            int ti = tIndex(fst[x]);
            if (ti != -1) {
                if (G.table[Ai][ti] != -1)
                    printf("  [WARNING] Grammar not LL(1): conflict at [%s][%s]\n",
                           G.nonTerminals[Ai], G.terminals[ti]);
                G.table[Ai][ti] = p;
            }
        }
        if (hasEps) {
            for (int x = 0; x < G.followCount[Ai]; x++) {
                int ti = tIndex(G.follow[Ai][x]);
                if (ti != -1) G.table[Ai][ti] = p;
            }
        }
    }
}

/* ============================================================
   PRINT RESULTS
   ============================================================ */
void printFirst() {
    printf("\n--- FIRST Sets ---\n");
    for (int i = 0; i < G.ntCount; i++) {
        printf("  FIRST(%-4s) = { ", G.nonTerminals[i]);
        for (int j = 0; j < G.firstCount[i]; j++)
            printf("%s%s", G.first[i][j], j+1<G.firstCount[i]?", ":"");
        printf(" }\n");
    }
}

void printFollow() {
    printf("\n--- FOLLOW Sets ---\n");
    for (int i = 0; i < G.ntCount; i++) {
        printf("  FOLLOW(%-4s) = { ", G.nonTerminals[i]);
        for (int j = 0; j < G.followCount[i]; j++)
            printf("%s%s", G.follow[i][j], j+1<G.followCount[i]?", ":"");
        printf(" }\n");
    }
}

void printTable() {
    printf("\n--- LL(1) Parsing Table ---\n");
    printf("  %-6s |", "NT");
    for (int t = 0; t < G.tCount; t++) printf(" %-10s|", G.terminals[t]);
    printf("\n  ");
    for (int x = 0; x < 8 + G.tCount * 12; x++) printf("-");
    printf("\n");
    for (int n = 0; n < G.ntCount; n++) {
        printf("  %-6s |", G.nonTerminals[n]);
        for (int t = 0; t < G.tCount; t++) {
            int p = G.table[n][t];
            if (p == -1) {
                printf(" %-10s|", "error");
            } else {
                char rhs[50] = "";
                if (G.prods[p].rhsLen == 0) {
                    strcpy(rhs, "eps");
                } else {
                    for (int k = 0; k < G.prods[p].rhsLen; k++) {
                        strcat(rhs, G.prods[p].rhs[k]);
                        if (k+1<G.prods[p].rhsLen) strcat(rhs," ");
                    }
                }
                char cell[50];
                snprintf(cell, sizeof(cell), "%s→%s", G.prods[p].lhs, rhs);
                printf(" %-10s|", cell);
            }
        }
        printf("\n");
    }
}

/* ============================================================
   LL(1) PARSER SIMULATION
   ============================================================ */
void simulateLL1(const char *input) {
    printf("\n--- LL(1) Parse of \"%s\" ---\n", input);

    /* Stack */
    char stack[200][MAX_LEN];
    int  top = 0;
    strcpy(stack[top++], ENDMARK);
    strcpy(stack[top++], G.startSymbol);

    /* Input pointer */
    char tokens[100][MAX_LEN];
    int  tpos = 0, tcount = 0;
    /* tokenize (each char is a token, $ at end) */
    for (int k = 0; input[k]; k++) {
        char ch[2] = {input[k], '\0'};
        strcpy(tokens[tcount++], ch);
    }
    strcpy(tokens[tcount++], ENDMARK);

    printf("  %-30s %-20s %s\n", "Stack", "Input", "Action");
    printf("  ");
    for (int x=0;x<65;x++) printf("-"); printf("\n");

    int accepted = 0, error = 0;
    while (top > 0 && !error) {
        /* Print stack */
        char stackStr[200] = "";
        for (int s = top-1; s >= 0; s--) {
            strcat(stackStr, stack[s]);
            if (s > 0) strcat(stackStr, " ");
        }
        /* Print remaining input */
        char inputStr[200] = "";
        for (int k = tpos; k < tcount; k++) {
            strcat(inputStr, tokens[k]);
            if (k+1<tcount) strcat(inputStr," ");
        }

        const char *X = stack[top-1];
        const char *a = tokens[tpos];

        if (strcmp(X, ENDMARK)==0 && strcmp(a, ENDMARK)==0) {
            printf("  %-30s %-20s ACCEPT\n", stackStr, inputStr);
            accepted = 1; break;
        }
        if (!isNT(X)) {
            /* terminal */
            if (strcmp(X, a)==0) {
                printf("  %-30s %-20s match '%s'\n", stackStr, inputStr, X);
                top--; tpos++;
            } else {
                printf("  %-30s %-20s ERROR: expected '%s'\n", stackStr, inputStr, X);
                error = 1;
            }
        } else {
            int ni = ntIndex(X);
            int ti = tIndex(a);
            if (ti == -1 || G.table[ni][ti] == -1) {
                printf("  %-30s %-20s ERROR: no rule for [%s][%s]\n", stackStr, inputStr, X, a);
                error = 1;
            } else {
                int p = G.table[ni][ti];
                /* build action string */
                char act[80];
                snprintf(act, sizeof(act), "%s →", G.prods[p].lhs);
                if (G.prods[p].rhsLen==0) strcat(act," ε");
                else for (int k=0;k<G.prods[p].rhsLen;k++) {
                    strcat(act," "); strcat(act, G.prods[p].rhs[k]);
                }
                printf("  %-30s %-20s %s\n", stackStr, inputStr, act);
                top--; /* pop X */
                /* push RHS in reverse */
                for (int k = G.prods[p].rhsLen-1; k >= 0; k--)
                    strcpy(stack[top++], G.prods[p].rhs[k]);
                /* remove epsilon from stack */
                if (top > 0 && strcmp(stack[top-1], EPSILON)==0) top--;
            }
        }
    }
    printf("  Parse result: %s\n", accepted ? "ACCEPTED" : "REJECTED");
}

/* ============================================================
   GRAMMAR SETUP HELPERS
   ============================================================ */
void addNT(const char *s) { strcpy(G.nonTerminals[G.ntCount++], s); }
void addT(const char *s)  { strcpy(G.terminals[G.tCount++], s); }
void addProd(const char *lhs, int rhsLen, ...) {
    Production *p = &G.prods[G.prodCount++];
    strcpy(p->lhs, lhs);
    p->rhsLen = rhsLen;
    va_list ap;
    va_start(ap, rhsLen);
    for (int i = 0; i < rhsLen; i++)
        strcpy(p->rhs[i], va_arg(ap, char *));
    va_end(ap);
}

/* ============================================================
   MAIN
   ============================================================ */
int main() {
    printf("===========================================\n");
    printf("   PREDICTIVE PARSING (LL(1)) — SESSION 06\n");
    printf("===========================================\n");

    /* ---- Assignment #6 Grammar ---- */
    /* S → aXd, X → YZ, Y → b | ε, Z → cX | ε */
    printf("\n[Grammar] S→aXd  X→YZ  Y→b|ε  Z→cX|ε\n");
    memset(&G, 0, sizeof(G));

    addNT("S"); addNT("X"); addNT("Y"); addNT("Z");
    addT("a"); addT("b"); addT("c"); addT("d"); addT(ENDMARK);
    strcpy(G.startSymbol, "S");

    /* S → a X d */
    addProd("S", 3, "a", "X", "d");
    /* X → Y Z */
    addProd("X", 2, "Y", "Z");
    /* Y → b */
    addProd("Y", 1, "b");
    /* Y → ε */
    addProd("Y", 0);
    /* Z → c X */
    addProd("Z", 2, "c", "X");
    /* Z → ε */
    addProd("Z", 0);

    computeFirst();
    computeFollow();
    buildLL1Table();

    printFirst();
    printFollow();
    printTable();
    simulateLL1("abcd");
    simulateLL1("ad");     /* Y→ε, Z→ε */
    simulateLL1("acd");    /* error */

    /* ---- Standard arithmetic grammar ---- */
    printf("\n\n[Grammar] Arithmetic: E→TE' E'→+TE'|ε T→FT' T'→*FT'|ε F→(E)|id\n");
    memset(&G, 0, sizeof(G));

    addNT("E"); addNT("E'"); addNT("T"); addNT("T'"); addNT("F");
    addT("id"); addT("+"); addT("*"); addT("("); addT(")"); addT(ENDMARK);
    strcpy(G.startSymbol, "E");

    addProd("E",  2, "T",  "E'");
    addProd("E'", 3, "+",  "T",   "E'");
    addProd("E'", 0);
    addProd("T",  2, "F",  "T'");
    addProd("T'", 3, "*",  "F",   "T'");
    addProd("T'", 0);
    addProd("F",  3, "(",  "E",   ")");
    addProd("F",  1, "id");

    computeFirst();
    computeFollow();
    buildLL1Table();

    printFirst();
    printFollow();
    printTable();
    simulateLL1("id+id*id");

    printf("\n===========================================\n");
    return 0;
}
