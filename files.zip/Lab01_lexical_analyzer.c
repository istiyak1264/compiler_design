/*
 * EXPERIMENT 1
 * OBJECTIVE: Design a lexical analyzer for a given language.
 * - Ignores redundant spaces, tabs, and new lines
 * - Ignores comments (// and /* style)
 * - Recognizes keywords, identifiers, operators, constants, and special symbols
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 100

/* List of C keywords to check against */
const char *keywords[] = {
    "for", "while", "do", "int", "float", "char", "double",
    "static", "switch", "case", "if", "else", "return", "void",
    "break", "continue", "struct", "typedef", "enum", "then", "endif", "print",
    NULL
};

/* Check if a string is a keyword */
int isKeyword(const char *str) {
    for (int i = 0; keywords[i] != NULL; i++) {
        if (strcmp(keywords[i], str) == 0)
            return 1;
    }
    return 0;
}

/* Check if a character is an operator */
int isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' ||
            c == '=' || c == '<' || c == '>' || c == '!' ||
            c == '&' || c == '|' || c == '%' || c == '^');
}

/* Check if a character is a special symbol */
int isSpecial(char c) {
    return (c == ',' || c == ';' || c == '(' || c == ')' ||
            c == '{' || c == '}' || c == '[' || c == ']' ||
            c == '.' || c == ':' || c == '#');
}

int main() {
    char source[5000];
    char ch;
    int i = 0;

    printf("========================================\n");
    printf("       LEXICAL ANALYZER - LAB 01        \n");
    printf("========================================\n");
    printf("Enter the source program (type EOF or press Ctrl+Z/Ctrl+D to end):\n");

    /* Read entire input */
    while ((ch = getchar()) != EOF && i < 4998) {
        source[i++] = ch;
    }
    source[i] = '\0';

    /* Storage arrays */
    char variables[50][MAX_LEN];  int varCount = 0;
    char ops[50][3];              int opCount  = 0;
    int  constants[100];          int conCount = 0;
    char kws[50][MAX_LEN];        int kwCount  = 0;
    char specials[100];           int spCount  = 0;
    char comment[1000];           int comFound = 0;

    int len = strlen(source);
    i = 0;

    while (i < len) {
        /* Skip whitespace */
        if (source[i] == ' ' || source[i] == '\t' || source[i] == '\n') {
            i++;
            continue;
        }

        /* Handle single-line comment // */
        if (source[i] == '/' && source[i+1] == '/') {
            i += 2;
            int ci = 0;
            while (i < len && source[i] != '\n') {
                comment[ci++] = source[i++];
            }
            comment[ci] = '\0';
            comFound = 1;
            continue;
        }

        /* Handle multi-line comment /* ... */
        if (source[i] == '/' && source[i+1] == '*') {
            i += 2;
            int ci = 0;
            while (i < len - 1 && !(source[i] == '*' && source[i+1] == '/')) {
                comment[ci++] = source[i++];
            }
            comment[ci] = '\0';
            i += 2; /* skip closing * and / */
            comFound = 1;
            continue;
        }

        /* Identifier or keyword */
        if (isalpha(source[i]) || source[i] == '_') {
            char token[MAX_LEN];
            int ti = 0;
            while (i < len && (isalnum(source[i]) || source[i] == '_')) {
                token[ti++] = source[i++];
            }
            token[ti] = '\0';

            /* Handle array notation like a[3] */
            char full[MAX_LEN];
            strcpy(full, token);
            if (i < len && source[i] == '[') {
                int fi = strlen(full);
                while (i < len && source[i] != ']') {
                    full[fi++] = source[i++];
                }
                if (i < len) full[fi++] = source[i++]; /* include ] */
                full[fi] = '\0';
            }

            if (isKeyword(token)) {
                /* store keyword */
                int dup = 0;
                for (int k = 0; k < kwCount; k++)
                    if (strcmp(kws[k], token) == 0) { dup = 1; break; }
                if (!dup && kwCount < 50)
                    strcpy(kws[kwCount++], token);
            } else {
                /* store as variable/identifier */
                int dup = 0;
                for (int k = 0; k < varCount; k++)
                    if (strcmp(variables[k], full) == 0) { dup = 1; break; }
                if (!dup && varCount < 50)
                    strcpy(variables[varCount++], full);
            }
            continue;
        }

        /* Number (constant) */
        if (isdigit(source[i]) || (source[i] == '-' && isdigit(source[i+1]) &&
            (i == 0 || source[i-1] == '=' || source[i-1] == '(' || source[i-1] == ' '))) {
            int neg = 0;
            if (source[i] == '-') { neg = 1; i++; }
            int val = 0;
            while (i < len && isdigit(source[i])) {
                val = val * 10 + (source[i] - '0');
                i++;
            }
            if (neg) val = -val;
            /* avoid duplicate */
            int dup = 0;
            for (int k = 0; k < conCount; k++)
                if (constants[k] == val) { dup = 1; break; }
            if (!dup && conCount < 100)
                constants[conCount++] = val;
            continue;
        }

        /* Operator */
        if (isOperator(source[i])) {
            char op[3] = {source[i], '\0', '\0'};
            /* two-char operators */
            if (i+1 < len && (source[i+1] == '=' || source[i+1] == source[i])) {
                op[1] = source[i+1];
                i++;
            }
            i++;
            /* avoid storing / since it was part of comments check */
            if (op[0] == '/') {
                /* standalone division */
            }
            int dup = 0;
            for (int k = 0; k < opCount; k++)
                if (strcmp(ops[k], op) == 0) { dup = 1; break; }
            if (!dup && opCount < 50)
                strcpy(ops[opCount++], op);
            continue;
        }

        /* Special symbol */
        if (isSpecial(source[i])) {
            int dup = 0;
            for (int k = 0; k < spCount; k++)
                if (specials[k] == source[i]) { dup = 1; break; }
            if (!dup && spCount < 100)
                specials[spCount++] = source[i];
            i++;
            continue;
        }

        i++; /* skip unrecognized */
    }

    /* Print results */
    printf("\n========== LEXICAL ANALYSIS RESULTS ==========\n");

    printf("\nVariables     : ");
    for (int k = 0; k < varCount; k++) printf("%s ", variables[k]);

    printf("\nOperators     : ");
    for (int k = 0; k < opCount; k++) printf("%s ", ops[k]);

    printf("\nConstants     : ");
    for (int k = 0; k < conCount; k++) printf("%d ", constants[k]);

    printf("\nKeywords      : ");
    for (int k = 0; k < kwCount; k++) printf("%s ", kws[k]);

    printf("\nSpecial Syms  : ");
    for (int k = 0; k < spCount; k++) printf("%c ", specials[k]);

    if (comFound)
        printf("\nComments      : %s", comment);

    printf("\n===============================================\n");
    return 0;
}
