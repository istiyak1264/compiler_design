/*
 * SESSION 3 — Symbol Table Construction and Management
 * OBJECTIVE: Build a symbol table from a token stream.
 * Supports: insert, update, delete, search, display operations.
 *
 * The token stream uses: [kw ...] [id ...] [op ...] [num ...] [sep ...] [par ...] [brc ...]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SYMBOLS 100
#define MAX_LEN     50

/* -------- Symbol Table Entry -------- */
typedef struct {
    int    slNo;
    char   name[MAX_LEN];
    char   idType[10];    /* var / func */
    char   dataType[10];  /* int / float / double / char / void */
    char   scope[20];     /* global / function-name */
    char   value[20];     /* known init value or "" */
    int    active;        /* 1 = in use, 0 = deleted */
} Symbol;

Symbol table[MAX_SYMBOLS];
int symCount = 0;
int nextId   = 1;

/* -------- Helper: trim leading spaces -------- */
void trim(char *s) {
    int i = 0, j = 0;
    while (s[i] == ' ' || s[i] == '\t') i++;
    while (s[i]) s[j++] = s[i++];
    s[j] = '\0';
}

/* -------- insert() -------- */
int insert(const char *name, const char *idType, const char *dataType,
           const char *scope, const char *value) {
    if (symCount >= MAX_SYMBOLS) {
        printf("  [ERROR] Symbol table is full!\n");
        return -1;
    }
    Symbol *e = &table[symCount];
    e->slNo   = nextId++;
    strncpy(e->name,     name,     MAX_LEN - 1);
    strncpy(e->idType,   idType,   9);
    strncpy(e->dataType, dataType, 9);
    strncpy(e->scope,    scope,    19);
    strncpy(e->value,    value,    19);
    e->active = 1;
    symCount++;
    printf("  [INSERT] '%s' added (id=%d).\n", name, e->slNo);
    return e->slNo;
}

/* -------- search() — returns index or -1 -------- */
int search(const char *name, const char *scope) {
    for (int i = 0; i < symCount; i++) {
        if (table[i].active &&
            strcmp(table[i].name, name) == 0 &&
            strcmp(table[i].scope, scope) == 0)
            return i;
    }
    /* try global scope if not found in local */
    for (int i = 0; i < symCount; i++) {
        if (table[i].active &&
            strcmp(table[i].name, name) == 0 &&
            strcmp(table[i].scope, "global") == 0)
            return i;
    }
    return -1;
}

/* -------- update() -------- */
void update(const char *name, const char *scope, const char *newValue) {
    int idx = search(name, scope);
    if (idx == -1) {
        printf("  [UPDATE] Symbol '%s' not found.\n", name);
        return;
    }
    strncpy(table[idx].value, newValue, 19);
    printf("  [UPDATE] '%s' value updated to '%s'.\n", name, newValue);
}

/* -------- delete() -------- */
void deleteSymbol(const char *name, const char *scope) {
    int idx = search(name, scope);
    if (idx == -1) {
        printf("  [DELETE] Symbol '%s' not found.\n", name);
        return;
    }
    table[idx].active = 0;
    printf("  [DELETE] '%s' removed from symbol table.\n", name);
}

/* -------- display() -------- */
void display() {
    printf("\n+------+----------------+--------+----------+------------+--------+\n");
    printf("| Sl.  | Name           | Id     | DataType | Scope      | Value  |\n");
    printf("+------+----------------+--------+----------+------------+--------+\n");
    for (int i = 0; i < symCount; i++) {
        if (!table[i].active) continue;
        printf("| %-4d | %-14s | %-6s | %-8s | %-10s | %-6s |\n",
               table[i].slNo,
               table[i].name,
               table[i].idType,
               table[i].dataType,
               table[i].scope,
               table[i].value);
    }
    printf("+------+----------------+--------+----------+------------+--------+\n");
}

/* -------- Parse token stream and build symbol table -------- */
void parseTokenStream(const char *stream) {
    /*
     * Very simplified parser for tokens like:
     * [kw float] [id x1] [op =] [num 3.125] [sep ;]
     * [kw double] [id f1] [par (] [kw int] [id x] [par )]
     * [brc {] [kw double] [id z] ... [brc }]
     */

    char tokens[200][MAX_LEN];
    char types[200][10];
    int  tCount = 0;

    /* Tokenize the stream */
    const char *p = stream;
    while (*p) {
        if (*p == '[') {
            p++;
            /* read type */
            char ttype[10], tval[MAX_LEN];
            int ti = 0;
            while (*p && *p != ' ' && *p != ']') ttype[ti++] = *p++;
            ttype[ti] = '\0';
            ti = 0;
            if (*p == ' ') p++;
            while (*p && *p != ']') tval[ti++] = *p++;
            tval[ti] = '\0';
            if (*p == ']') p++;

            strncpy(types[tCount], ttype, 9);
            strncpy(tokens[tCount], tval, MAX_LEN - 1);
            tCount++;
        } else {
            p++;
        }
    }

    /* Walk tokens to build symbol table */
    char currentScope[20] = "global";
    char scopeStack[10][20];
    int  scopeTop = 0;
    strcpy(scopeStack[0], "global");

    for (int i = 0; i < tCount; i++) {
        /* detect function definition: kw <type> id <name> par ( */
        if (strcmp(types[i], "kw") == 0 &&
            (strcmp(tokens[i], "int")    == 0 ||
             strcmp(tokens[i], "double") == 0 ||
             strcmp(tokens[i], "float")  == 0 ||
             strcmp(tokens[i], "char")   == 0)  &&
            i + 1 < tCount && strcmp(types[i+1], "id") == 0 &&
            i + 2 < tCount && strcmp(types[i+2], "par") == 0 &&
            strcmp(tokens[i+2], "(") == 0) {

            /* It's a function declaration */
            char funcName[MAX_LEN];
            strcpy(funcName, tokens[i+1]);
            insert(funcName, "func", tokens[i], currentScope, "");

            /* Push function as new scope */
            strcpy(currentScope, funcName);
            if (scopeTop < 9) {
                scopeTop++;
                strcpy(scopeStack[scopeTop], funcName);
            }
            i += 2; /* skip id and ( */
            continue;
        }

        /* Variable declaration: kw <type> id <name> */
        if (strcmp(types[i], "kw") == 0 &&
            (strcmp(tokens[i], "int")    == 0 ||
             strcmp(tokens[i], "double") == 0 ||
             strcmp(tokens[i], "float")  == 0 ||
             strcmp(tokens[i], "char")   == 0) &&
            i + 1 < tCount && strcmp(types[i+1], "id") == 0) {

            char varName[MAX_LEN], varType[MAX_LEN], varVal[MAX_LEN];
            strcpy(varType, tokens[i]);
            strcpy(varName, tokens[i+1]);
            strcpy(varVal, "");

            /* Check for initialization: [op =] [num val] */
            if (i + 3 < tCount &&
                strcmp(types[i+2], "op") == 0 && strcmp(tokens[i+2], "=") == 0 &&
                strcmp(types[i+3], "num") == 0) {
                strcpy(varVal, tokens[i+3]);
                i += 2; /* skip = num */
            }

            /* Don't re-insert if already there */
            if (search(varName, currentScope) == -1)
                insert(varName, "var", varType, currentScope, varVal);
            i += 1;
            continue;
        }

        /* Closing brace: pop scope */
        if (strcmp(types[i], "brc") == 0 && strcmp(tokens[i], "}") == 0) {
            if (scopeTop > 0) {
                scopeTop--;
                strcpy(currentScope, scopeStack[scopeTop]);
            }
        }
    }
}

/* -------- Menu-driven main -------- */
int main() {
    printf("===========================================\n");
    printf("   SYMBOL TABLE MANAGER — SESSION 03      \n");
    printf("===========================================\n");

    /* --- Build from sample token stream (from the PDF) --- */
    printf("\n[*] Parsing sample token stream from PDF...\n");
    const char *sampleStream =
        "[kw float] [id x1] [op =] [num 3.125] [sep ;] "
        "[kw double] [id f1] [par (] [kw int] [id x] [par )] "
        "[brc {] [kw double] [id z] [sep ;] [id z] [op =] [num 0.01] [sep ;] "
        "[kw return] [id z] [sep ;] [brc }] "
        "[kw int] [id main] [par (] [kw void] [par )] "
        "[brc {] [kw int] [id n1] [sep ;] [kw double] [id z] [sep ;] "
        "[id n1] [op =] [num 25] [sep ;] "
        "[id z] [op =] [id f1] [par (] [id n1] [par )] [sep ;] [brc }]";

    parseTokenStream(sampleStream);

    printf("\n[*] Initial Symbol Table:\n");
    display();

    /* --- Interactive menu --- */
    int opt;
    do {
        printf("\n--- Operations ---\n");
        printf("  1. Insert  symbol\n");
        printf("  2. Search  symbol\n");
        printf("  3. Update  symbol value\n");
        printf("  4. Delete  symbol\n");
        printf("  5. Display symbol table\n");
        printf("  0. Exit\n");
        printf("Choice: ");
        scanf("%d", &opt);
        getchar();

        char name[MAX_LEN], scope[20], val[20], idType[10], dataType[10];

        switch (opt) {
            case 1:
                printf("  Name     : "); fgets(name, MAX_LEN, stdin); name[strcspn(name,"\n")]=0;
                printf("  Id type  (var/func): "); fgets(idType, 10, stdin); idType[strcspn(idType,"\n")]=0;
                printf("  DataType (int/float/double/char): "); fgets(dataType, 10, stdin); dataType[strcspn(dataType,"\n")]=0;
                printf("  Scope    : "); fgets(scope, 20, stdin); scope[strcspn(scope,"\n")]=0;
                printf("  Value    : "); fgets(val, 20, stdin); val[strcspn(val,"\n")]=0;
                insert(name, idType, dataType, scope, val);
                break;

            case 2:
                printf("  Name : "); fgets(name, MAX_LEN, stdin); name[strcspn(name,"\n")]=0;
                printf("  Scope: "); fgets(scope, 20, stdin); scope[strcspn(scope,"\n")]=0;
                {
                    int idx = search(name, scope);
                    if (idx == -1)
                        printf("  [SEARCH] '%s' not found.\n", name);
                    else
                        printf("  [SEARCH] Found '%s' at slot %d (type=%s, scope=%s, val=%s)\n",
                               name, table[idx].slNo, table[idx].dataType,
                               table[idx].scope, table[idx].value);
                }
                break;

            case 3:
                printf("  Name     : "); fgets(name, MAX_LEN, stdin); name[strcspn(name,"\n")]=0;
                printf("  Scope    : "); fgets(scope, 20, stdin); scope[strcspn(scope,"\n")]=0;
                printf("  New value: "); fgets(val, 20, stdin); val[strcspn(val,"\n")]=0;
                update(name, scope, val);
                break;

            case 4:
                printf("  Name : "); fgets(name, MAX_LEN, stdin); name[strcspn(name,"\n")]=0;
                printf("  Scope: "); fgets(scope, 20, stdin); scope[strcspn(scope,"\n")]=0;
                deleteSymbol(name, scope);
                break;

            case 5:
                display();
                break;

            case 0:
                break;

            default:
                printf("  Invalid choice.\n");
        }
    } while (opt != 0);

    printf("\n===========================================\n");
    return 0;
}
