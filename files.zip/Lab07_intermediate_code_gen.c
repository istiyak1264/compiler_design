/*
 * SESSION 7 — Intermediate Code Generation & Machine Code Generation
 * OBJECTIVE:
 *   1. Generate 3-address code for a given arithmetic expression.
 *   2. Generate machine (assembly-like) code from a 3-address code file.
 *
 * Sample input:  w = a - b * c / d + e - f
 * 3-addr output:
 *   t1 = b * c
 *   t2 = t1 / d
 *   t3 = a - t2
 *   t4 = t3 + e
 *   t5 = t4 - f
 *   w  = t5
 *
 * Machine code output (from 3-addr code):
 *   X=a-b → MOV R0,a  / SUB R0,b
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* ============================================================
   PART 1 — 3-ADDRESS CODE GENERATION
   Uses operator-precedence with a manual expression parser.
   Produces a sequence of: Ti = operand1 op operand2
   ============================================================ */

#define MAX_EXPR  256
#define MAX_TAC   200
#define MAX_SYM   20

/* --- Temporary variable counter --- */
int tempCount = 0;
char newTemp[MAX_SYM];
void getTemp() {
    snprintf(newTemp, MAX_SYM, "t%d", ++tempCount);
}

/* --- Three-address code instruction --- */
typedef struct {
    char result[MAX_SYM];
    char arg1[MAX_SYM];
    char op[4];
    char arg2[MAX_SYM];  /* empty for unary / copy */
} TACInstr;

TACInstr tacCode[MAX_TAC];
int      tacCount = 0;

void emitTAC(const char *result, const char *arg1, const char *op, const char *arg2) {
    TACInstr *t = &tacCode[tacCount++];
    strcpy(t->result, result);
    strcpy(t->arg1,   arg1);
    strcpy(t->op,     op);
    strcpy(t->arg2,   arg2);
}

/* --- Expression parser (recursive descent) --- */
char exprStr[MAX_EXPR];
int  epos;

void skipWS() { while (exprStr[epos]==' '||exprStr[epos]=='\t') epos++; }

/* Forward declarations */
void parseExpr(char *result);
void parseTerm(char *result);
void parseFactor(char *result);

void parseExpr(char *result) {
    char left[MAX_SYM];
    parseTerm(left);
    skipWS();
    while (exprStr[epos]=='+' || exprStr[epos]=='-') {
        char op[2] = {exprStr[epos], '\0'};
        epos++;
        skipWS();
        char right[MAX_SYM];
        parseTerm(right);
        getTemp();
        emitTAC(newTemp, left, op, right);
        strcpy(left, newTemp);
        skipWS();
    }
    strcpy(result, left);
}

void parseTerm(char *result) {
    char left[MAX_SYM];
    parseFactor(left);
    skipWS();
    while (exprStr[epos]=='*' || exprStr[epos]=='/') {
        char op[2] = {exprStr[epos], '\0'};
        epos++;
        skipWS();
        char right[MAX_SYM];
        parseFactor(right);
        getTemp();
        emitTAC(newTemp, left, op, right);
        strcpy(left, newTemp);
        skipWS();
    }
    strcpy(result, left);
}

void parseFactor(char *result) {
    skipWS();
    if (exprStr[epos] == '(') {
        epos++;
        parseExpr(result);
        if (exprStr[epos] == ')') epos++;
    } else {
        /* operand: identifier or number */
        int j = 0;
        while (exprStr[epos] && exprStr[epos]!=' ' &&
               exprStr[epos]!='+' && exprStr[epos]!='-' &&
               exprStr[epos]!='*' && exprStr[epos]!='/' &&
               exprStr[epos]!=')' && exprStr[epos]!='(') {
            result[j++] = exprStr[epos++];
        }
        result[j] = '\0';
    }
}

void printTAC() {
    printf("\n  %-10s  %-8s %-4s %-8s\n", "Result", "Arg1", "Op", "Arg2");
    printf("  ");
    for (int i=0;i<38;i++) printf("-"); printf("\n");
    for (int i = 0; i < tacCount; i++) {
        if (strlen(tacCode[i].op)==0)
            printf("  %-10s= %-8s\n", tacCode[i].result, tacCode[i].arg1);
        else
            printf("  %-10s= %-8s %-4s %-8s\n",
                   tacCode[i].result, tacCode[i].arg1, tacCode[i].op, tacCode[i].arg2);
    }
}

/* ============================================================
   PART 2 — MACHINE CODE GENERATION from 3-address code
   Maps each 3-address instruction to register-based assembly.
   Uses a simple register pool: R0, R1, R2, R3, ...
   ============================================================ */

#define MAX_REGS 8

typedef struct {
    char holds[MAX_SYM]; /* which variable/temp this reg holds, "" = free */
} Register;

Register regs[MAX_REGS];
int      regUsed = 0;

void initRegs() {
    for (int i=0;i<MAX_REGS;i++) strcpy(regs[i].holds, "");
    regUsed = 0;
}

/* Find register holding value, or -1 */
int findReg(const char *val) {
    for (int i=0;i<regUsed;i++)
        if (strcmp(regs[i].holds, val)==0) return i;
    return -1;
}

/* Allocate a new register */
int allocReg(const char *val) {
    int r = regUsed < MAX_REGS ? regUsed++ : 0; /* simple: reuse R0 if full */
    strcpy(regs[r].holds, val);
    return r;
}

void generateMachineCode() {
    printf("\n  %-20s %s\n", "3-Addr Stmt", "Target Code");
    printf("  ");
    for (int i=0;i<55;i++) printf("-"); printf("\n");

    initRegs();

    for (int i = 0; i < tacCount; i++) {
        TACInstr *t = &tacCode[i];
        char stmt[64];

        if (strlen(t->op)==0) {
            /* copy: result = arg1 */
            snprintf(stmt, sizeof(stmt), "%s=%s", t->result, t->arg1);
            int r1 = findReg(t->arg1);
            int rr;
            if (r1 != -1) {
                rr = allocReg(t->result);
                printf("  %-20s MOV R%d,R%d\n", stmt, rr, r1);
            } else {
                rr = allocReg(t->result);
                printf("  %-20s MOV R%d,%s\n", stmt, rr, t->arg1);
            }
        } else {
            snprintf(stmt, sizeof(stmt), "%s=%s%s%s",
                     t->result, t->arg1, t->op, t->arg2);

            /* Load arg1 into register */
            int r1 = findReg(t->arg1);
            int rResult;
            if (r1 == -1) {
                rResult = allocReg(t->result);
                printf("  %-20s MOV R%d,%s\n", stmt, rResult, t->arg1);
            } else {
                rResult = r1;
                strcpy(regs[rResult].holds, t->result);
                printf("  %-20s \n", stmt);
            }

            /* Determine operation mnemonic */
            const char *mnem = "OP";
            if (strcmp(t->op,"+")==0) mnem="ADD";
            if (strcmp(t->op,"-")==0) mnem="SUB";
            if (strcmp(t->op,"*")==0) mnem="MUL";
            if (strcmp(t->op,"/")==0) mnem="DIV";

            /* arg2 */
            int r2 = findReg(t->arg2);
            if (r2 != -1)
                printf("  %-20s %s R%d,R%d\n", "", mnem, rResult, r2);
            else
                printf("  %-20s %s R%d,%s\n", "", mnem, rResult, t->arg2);
        }
    }
}

/* ============================================================
   PART 3 — MACHINE CODE FROM FILE (Assignment #7)
   Reads 3-addr code from a text file, line by line.
   Each line format:  result = arg1 op arg2
                  or: result = arg1         (copy)
   ============================================================ */

void generateMachineCodeFromFile(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        printf("  [ERROR] Cannot open file '%s'\n", filename);
        return;
    }
    printf("\n--- Machine Code from File: %s ---\n", filename);
    printf("  %-20s %s\n", "Statement", "Target Code");
    printf("  ");
    for (int i=0;i<55;i++) printf("-"); printf("\n");

    initRegs();
    char line[256];
    int regIdx = 0;

    while (fgets(line, sizeof(line), fp)) {
        /* Remove newline */
        line[strcspn(line,"\n")] = '\0';
        /* Skip empty lines */
        int blank = 1;
        for (int k=0;line[k];k++) if (!isspace(line[k])) { blank=0; break; }
        if (blank) continue;

        char result[32]="", arg1[32]="", op[4]="", arg2[32]="";
        /* Parse: result = arg1 op arg2  OR  result = arg1 */
        int parts = sscanf(line, "%s = %s %s %s", result, arg1, op, arg2);

        if (parts >= 2) {
            printf("  %-20s MOV R%d,%s\n", line, regIdx, arg1);
            if (parts == 4) {
                const char *mnem = "OP";
                if (strcmp(op,"+")==0) mnem="ADD";
                if (strcmp(op,"-")==0) mnem="SUB";
                if (strcmp(op,"*")==0) mnem="MUL";
                if (strcmp(op,"/")==0) mnem="DIV";
                printf("  %-20s %s R%d,%s\n", "", mnem, regIdx, arg2);
            }
            regIdx = (regIdx + 1) % MAX_REGS;
        }
    }
    fclose(fp);
}

/* ============================================================
   MAIN
   ============================================================ */
int main() {
    printf("===========================================\n");
    printf(" INTERMEDIATE & MACHINE CODE — SESSION 07 \n");
    printf("===========================================\n");

    /* ---- Part 1: 3-address code from expression ---- */
    char assignment[MAX_EXPR];
    printf("\n[PART 1] Three-Address Code Generation\n");
    printf("Enter assignment (e.g.  w = a-b*c/d+e-f): ");
    fgets(assignment, MAX_EXPR, stdin);
    assignment[strcspn(assignment,"\n")] = '\0';

    /* Split at first '=' */
    char lhsVar[MAX_SYM] = "";
    char rhsExpr[MAX_EXPR] = "";
    char *eq = strchr(assignment, '=');
    if (eq) {
        strncpy(lhsVar, assignment, eq - assignment);
        /* trim lhsVar */
        int li = strlen(lhsVar) - 1;
        while (li >= 0 && isspace(lhsVar[li])) lhsVar[li--] = '\0';
        strcpy(rhsExpr, eq + 1);
    } else {
        strcpy(rhsExpr, assignment);
        strcpy(lhsVar, "res");
    }

    /* Parse and generate TAC */
    strcpy(exprStr, rhsExpr);
    epos = 0; tempCount = 0; tacCount = 0;

    char topResult[MAX_SYM];
    parseExpr(topResult);
    /* Final assignment: lhsVar = topResult */
    emitTAC(lhsVar, topResult, "", "");

    printf("\n  Three-Address Code for: %s\n", assignment);
    printTAC();

    /* ---- Part 2: machine code from TAC ---- */
    printf("\n[PART 2] Machine Code Generation\n");
    generateMachineCode();

    /* ---- Part 3: machine code from file (Assignment #7) ---- */
    printf("\n[PART 3] Machine Code from 3-Addr Code File (Assignment #7)\n");

    /* Create a sample 3-addr code file as in the PDF */
    FILE *fp = fopen("tac_input.txt", "w");
    if (fp) {
        fprintf(fp, "X = a - b\n");
        fprintf(fp, "Y = a + c\n");
        fprintf(fp, "Z = d + b\n");
        fprintf(fp, "C = a - d\n");
        fclose(fp);
        printf("  (Created sample file 'tac_input.txt' matching PDF example)\n");
        generateMachineCodeFromFile("tac_input.txt");
    }

    /* Also handle user-provided file */
    printf("\nEnter 3-addr code filename to process (or press Enter to skip): ");
    char fname[100];
    fgets(fname, sizeof(fname), stdin);
    fname[strcspn(fname,"\n")] = '\0';
    if (strlen(fname) > 0)
        generateMachineCodeFromFile(fname);

    printf("\n===========================================\n");
    return 0;
}
